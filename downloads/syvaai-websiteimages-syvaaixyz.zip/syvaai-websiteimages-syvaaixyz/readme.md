# Most files in this folder are created and property of SyväAI (Daniel Grimsley)

## Some files in this folder are not created and not owned by SyväAI (Daniel Grimsley).

# The folling files are from Saepul Nahwan:

user.png

# These following files are from Freepik:

day-and-night.png

## All the logos in "debitcards (3)" are not property of SyväAI, and are owned by the brands shown on them.

## All files in "Chat" are from missing orgin, most likely Wikimedia Commons, or FreePik. If you are the creator of those files, please contact us at our contact page.


