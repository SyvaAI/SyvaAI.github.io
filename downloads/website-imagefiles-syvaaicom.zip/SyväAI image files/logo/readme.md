## All of these files are NOT open source, and are property of SyväAI.
