# Most files in this folder are created and property of SyväAI (Daniel Grimsley)

## Some files in this folder are not created and not owned by SyväAI (Daniel Grimsley).

# The folling files are from Canva Graphics (Sketchify), and have been slightly edited for our website.

84963931-de27-4b22-b521-1d9e604e0630.png
people-talking.png


## All the logos in "debitcards (3)" are not property of SyväAI, and are owned by the brands shown on them.

## All files in "Chat" are from missing orgin, most likely Wikimedia Commons, or FreePik. If you are the creator of those files, please contact us at our contact page.

## All files in "crypto" are non-functonal crypto wallet QR codes to our cyrpto wallet. Those do not work, the wallet adress accosiated with it has been removed..


